# Actas SICMA hasta el 5 de octubre de 2026

Versión 1.2. Todos los campos están completados. Modalidad, coordinación, fase, decisiones, respuestas de revisión y compromisos se presentan como un escenario ficticio para validación del equipo. No son registros de aprobación ni evidencia de ejecución. No se incorporan firmas.

Se conserva la asistencia de las primeras 21 reuniones informada por Claudio. La asistencia del 5 de octubre es simulada. Las referencias documentales son fuentes actuales de contexto, no prueba de que se usaran en cada fecha.

Proyecto: 15/08–19/12/2026. Trabajo: 15 h semanales por integrante; reuniones adicionales lunes, miércoles y viernes de 20:00 a 21:00. Plan: 720 h-persona y 90 h de reserva.

- [Acta_SICMA_2026-08-17_001.docx](Acta_SICMA_2026-08-17_001.docx) — Inicio y propósito de SICMA. Definir el problema que abordaría SICMA en un datacenter simulado.
- [Acta_SICMA_2026-08-19_002.docx](Acta_SICMA_2026-08-19_002.docx) — Alcance y usuarios. Delimitar las funciones esenciales y los usuarios del sistema.
- [Acta_SICMA_2026-08-21_003.docx](Acta_SICMA_2026-08-21_003.docx) — Organización y seguimiento. Proponer una distribución del trabajo y un mecanismo de seguimiento.
- [Acta_SICMA_2026-08-24_004.docx](Acta_SICMA_2026-08-24_004.docx) — Requerimientos funcionales. Convertir las necesidades del proyecto en requisitos comprobables.
- [Acta_SICMA_2026-08-26_005.docx](Acta_SICMA_2026-08-26_005.docx) — Casos de uso y roles. Relacionar los requisitos con acciones concretas de cada usuario.
- [Acta_SICMA_2026-08-28_006.docx](Acta_SICMA_2026-08-28_006.docx) — Arquitectura y contratos. Definir cómo se comunicarían los componentes de SICMA.
- [Acta_SICMA_2026-08-31_007.docx](Acta_SICMA_2026-08-31_007.docx) — Modelo de datos. Revisar las entidades y relaciones necesarias para el prototipo.
- [Acta_SICMA_2026-09-02_008.docx](Acta_SICMA_2026-09-02_008.docx) — Diseño de interfaces. Proponer pantallas que respondan a las tareas de cada rol.
- [Acta_SICMA_2026-09-04_009.docx](Acta_SICMA_2026-09-04_009.docx) — Planificación y dependencias. Ordenar el trabajo por dependencias y entregables del semestre.
- [Acta_SICMA_2026-09-07_010.docx](Acta_SICMA_2026-09-07_010.docx) — Autenticación y cuentas. Detallar el acceso al sistema y la administración de usuarios.
- [Acta_SICMA_2026-09-09_011.docx](Acta_SICMA_2026-09-09_011.docx) — Gestión de activos. Precisar el registro y la consulta de activos del laboratorio.
- [Acta_SICMA_2026-09-11_012.docx](Acta_SICMA_2026-09-11_012.docx) — Monitoreo ambiental. Definir la recepción y consulta de temperatura y humedad.
- [Acta_SICMA_2026-09-14_013.docx](Acta_SICMA_2026-09-14_013.docx) — Alertas y notificaciones. Precisar qué eventos generarían alertas y notificaciones.
- [Acta_SICMA_2026-09-16_014.docx](Acta_SICMA_2026-09-16_014.docx) — Integración con Zabbix. Definir el intercambio de información con la herramienta de monitoreo.
- [Acta_SICMA_2026-09-18_015.docx](Acta_SICMA_2026-09-18_015.docx) — Accesos y proveedor HID. Delimitar la integración de acceso físico dentro del prototipo.
- [Acta_SICMA_2026-09-21_016.docx](Acta_SICMA_2026-09-21_016.docx) — Solicitudes y agenda. Detallar el flujo de solicitudes con Forms y Power Automate.
- [Acta_SICMA_2026-09-23_017.docx](Acta_SICMA_2026-09-23_017.docx) — Ciclo de intervenciones. Precisar los cambios de estado y la responsabilidad del técnico.
- [Acta_SICMA_2026-09-25_018.docx](Acta_SICMA_2026-09-25_018.docx) — Consultas móviles. Revisar el alcance de Ionic y su relación con la API.
- [Acta_SICMA_2026-09-28_019.docx](Acta_SICMA_2026-09-28_019.docx) — Informes y gobernanza de datos. Definir la información analítica y sus reglas de uso.
- [Acta_SICMA_2026-09-30_020.docx](Acta_SICMA_2026-09-30_020.docx) — Infraestructura y seguridad. Revisar el entorno de ejecución y las pruebas de disponibilidad.
- [Acta_SICMA_2026-10-02_021.docx](Acta_SICMA_2026-10-02_021.docx) — Pruebas y calidad. Organizar la validación funcional, de integración y de seguridad.
- [Acta_SICMA_2026-10-05_022.docx](Acta_SICMA_2026-10-05_022.docx) — Alineación de documentación y capacidad. Revisar alcance, horas y evidencias antes de continuar la ejecución.