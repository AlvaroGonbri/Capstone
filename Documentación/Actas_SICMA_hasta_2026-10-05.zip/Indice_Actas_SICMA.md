# Actas de reunión SICMA

Corte del registro: 5 de octubre de 2026, antes de la reunión de las 20:00, hora de Chile.

Se preparan 21 registros retrospectivos y un borrador para la reunión del 5 de octubre. Se conserva la plantilla de Documentación/SICMA_Formato_Acta_de_Reunion.docx.

Claudio confirmó la asistencia de los tres integrantes a las sesiones pasadas. El detalle de avances, dudas, decisiones y compromisos aún debe completarse y validarse por fecha. Ninguna de estas actas se presenta como aprobada.

Las fechas se generan a partir del calendario confirmado: lunes, miércoles y viernes, 20:00–21:00. Se incluyen los feriados que coinciden con ese calendario, según la confirmación de asistencia a todas las reuniones; cualquier excepción real debe corregirse.

Proyecto: 15/08/2026–19/12/2026, 18 semanas. Trabajo: 810 horas-persona de capacidad, 720 planificadas y 90 de reserva. Reuniones adicionales: 54 sesiones previstas en el semestre, 162 horas-persona. Las 21 sesiones pasadas representan 63 horas-persona; la de hoy no se contabiliza como realizada.

| Acta | Fecha | Estado |
|---|---|---|
| [ACT-SICMA-001](Acta_SICMA_2026-08-17_001.docx) | 17/08/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-002](Acta_SICMA_2026-08-19_002.docx) | 19/08/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-003](Acta_SICMA_2026-08-21_003.docx) | 21/08/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-004](Acta_SICMA_2026-08-24_004.docx) | 24/08/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-005](Acta_SICMA_2026-08-26_005.docx) | 26/08/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-006](Acta_SICMA_2026-08-28_006.docx) | 28/08/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-007](Acta_SICMA_2026-08-31_007.docx) | 31/08/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-008](Acta_SICMA_2026-09-02_008.docx) | 02/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-009](Acta_SICMA_2026-09-04_009.docx) | 04/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-010](Acta_SICMA_2026-09-07_010.docx) | 07/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-011](Acta_SICMA_2026-09-09_011.docx) | 09/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-012](Acta_SICMA_2026-09-11_012.docx) | 11/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-013](Acta_SICMA_2026-09-14_013.docx) | 14/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-014](Acta_SICMA_2026-09-16_014.docx) | 16/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-015](Acta_SICMA_2026-09-18_015.docx) | 18/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-016](Acta_SICMA_2026-09-21_016.docx) | 21/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-017](Acta_SICMA_2026-09-23_017.docx) | 23/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-018](Acta_SICMA_2026-09-25_018.docx) | 25/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-019](Acta_SICMA_2026-09-28_019.docx) | 28/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-020](Acta_SICMA_2026-09-30_020.docx) | 30/09/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-021](Acta_SICMA_2026-10-02_021.docx) | 02/10/2026 | Realizada según confirmación; acta por validar |
| [ACT-SICMA-022](Acta_SICMA_2026-10-05_022.docx) | 05/10/2026 | Programada |
