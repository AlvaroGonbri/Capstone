# Propuestas de contenido para las actas de SICMA

Versión 1.1 elaborada el 5 de octubre de 2026, hora de Chile.

**Los temas, avances, dudas, decisiones, responsables y plazos propuestos son hipotéticos. No son prueba de lo conversado ni de trabajo ejecutado. Deben corregirse y validarse antes de usar las actas como registros definitivos.**

Se conservan las fechas y el horario habitual informados por Claudio y su confirmación de asistencia de los tres integrantes a las 21 reuniones del 17/08 al 02/10. Para la reunión del 05/10, la realización y la asistencia siguen pendientes de confirmación; el paso de la hora prevista no las acredita.

La secuencia temática es una propuesta de revisión ligada a SICMA, no una reconstrucción histórica demostrada. Los documentos vigentes orientan el contenido, pero no prueban que se trataran esos asuntos en cada fecha.

Calendario: lunes, miércoles y viernes, 20:00–21:00, America/Santiago. Proyecto del 15/08 al 19/12/2026: 18 semanas, 810 horas-persona de trabajo, 720 estimadas y 90 de reserva. Las reuniones son adicionales: 162 horas-persona previstas en el semestre.

Para validar cada acta: contrastar los temas con notas o mensajes, corregir decisiones y compromisos, adjuntar evidencia real y registrar la revisión de los participantes. Los plazos sugeridos no se deben tratar como vencimientos históricos reales.

| Acta | Fecha | Tema propuesto |
|---|---|---|
| [ACT-SICMA-001](Acta_SICMA_2026-08-17_001.docx) | 17/08/2026 | Inicio y propósito de SICMA |
| [ACT-SICMA-002](Acta_SICMA_2026-08-19_002.docx) | 19/08/2026 | Alcance y usuarios |
| [ACT-SICMA-003](Acta_SICMA_2026-08-21_003.docx) | 21/08/2026 | Organización y seguimiento |
| [ACT-SICMA-004](Acta_SICMA_2026-08-24_004.docx) | 24/08/2026 | Requerimientos funcionales |
| [ACT-SICMA-005](Acta_SICMA_2026-08-26_005.docx) | 26/08/2026 | Casos de uso y roles |
| [ACT-SICMA-006](Acta_SICMA_2026-08-28_006.docx) | 28/08/2026 | Arquitectura y contratos |
| [ACT-SICMA-007](Acta_SICMA_2026-08-31_007.docx) | 31/08/2026 | Modelo de datos |
| [ACT-SICMA-008](Acta_SICMA_2026-09-02_008.docx) | 02/09/2026 | Diseño de interfaces |
| [ACT-SICMA-009](Acta_SICMA_2026-09-04_009.docx) | 04/09/2026 | Planificación y dependencias |
| [ACT-SICMA-010](Acta_SICMA_2026-09-07_010.docx) | 07/09/2026 | Autenticación y cuentas |
| [ACT-SICMA-011](Acta_SICMA_2026-09-09_011.docx) | 09/09/2026 | Gestión de activos |
| [ACT-SICMA-012](Acta_SICMA_2026-09-11_012.docx) | 11/09/2026 | Monitoreo ambiental |
| [ACT-SICMA-013](Acta_SICMA_2026-09-14_013.docx) | 14/09/2026 | Alertas y notificaciones |
| [ACT-SICMA-014](Acta_SICMA_2026-09-16_014.docx) | 16/09/2026 | Integración con Zabbix |
| [ACT-SICMA-015](Acta_SICMA_2026-09-18_015.docx) | 18/09/2026 | Accesos y proveedor HID |
| [ACT-SICMA-016](Acta_SICMA_2026-09-21_016.docx) | 21/09/2026 | Solicitudes y agenda |
| [ACT-SICMA-017](Acta_SICMA_2026-09-23_017.docx) | 23/09/2026 | Ciclo de intervenciones |
| [ACT-SICMA-018](Acta_SICMA_2026-09-25_018.docx) | 25/09/2026 | Consultas móviles |
| [ACT-SICMA-019](Acta_SICMA_2026-09-28_019.docx) | 28/09/2026 | Informes y gobernanza de datos |
| [ACT-SICMA-020](Acta_SICMA_2026-09-30_020.docx) | 30/09/2026 | Infraestructura y seguridad |
| [ACT-SICMA-021](Acta_SICMA_2026-10-02_021.docx) | 02/10/2026 | Pruebas y calidad |
| [ACT-SICMA-022](Acta_SICMA_2026-10-05_022.docx) | 05/10/2026 | Alineación de documentación y capacidad |
